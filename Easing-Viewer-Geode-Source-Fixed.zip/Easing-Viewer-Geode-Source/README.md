# Easing Viewer (Geode source)

A source fork of Better Easings Menu for Geometry Dash 2.2081 and Geode 5.10.1. It keeps the original trigger-popup easing selector and its trigger-specific property handling as a foundation for Easing Viewer.

## Build

1. Install the Geode SDK for your platform.
2. Set the `GEODE_SDK` environment variable to the SDK directory.
3. Configure and build this folder with CMake using the Geode toolchain/workflow appropriate to your platform.
4. Package the resulting mod using Geode's build output.

## Current implementation

This starter fork preserves the original easing selector (19 easing entries, including None, Ease, Elastic, Bounce, Exponential, Sine, and Back variants) and trigger integration. It does **not yet** implement animated curve previews, Duration/Ease Rate controls, or an apply/OK workflow. Those require additional UI and trigger-value handling and have not been verified against the SDK in this environment.

Original project: https://github.com/willy-270/Better-Easings-Menu
